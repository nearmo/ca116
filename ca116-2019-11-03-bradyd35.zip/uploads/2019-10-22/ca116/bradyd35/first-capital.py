#!/usr/bin/env python

s = raw_input()
i = 0

while (i < len(s)) and ("Z" < s[i] or s[i] < "A"):
    i = i + 1

if i < len(s):
    print s[i], i
