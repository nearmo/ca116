#!/usr/bin/env python

s = raw_input()
i = 0

while i < len(s) and s[i] != s[i +1]:
    i = i + 1

if i < len(s):
    print s[i:i + 2]
