#!/usr/bin/env python

i = 0
s = raw_input()

while s[i] < "a" or "g" < s[i]:
    i = i + 1
print s[i]
