#!/usr/bin/env python

i = 0
s = raw_input()

while i < len(s) and (s[i] < "A" or "Z" < s[i]):
    i = i + 1
print i
