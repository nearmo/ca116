#!/usr/bin/env python

a = []
s = raw_input()
while s != "end":
    a.append(s)
    s = raw_input()
print a
