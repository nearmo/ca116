#!/usr/bin/env python

a = []
s = raw_input()

while s != "end":
    a.append(s)
    s = raw_input()

i = 0

while i < len(a):
    if int(a[i]) % 2 == 0:
        print a[i]
    i = i + 1

j = 0

while j < len(a):
    if int(a[j]) % 2 != 0:
        print a[j]
    j = j + 1
