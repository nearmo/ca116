#!/usr/bin/env python

import sys
args = sys.argv[1:]

i = 0
while i < len(args):
   print args[i]
   i = i + 1
