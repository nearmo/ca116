#!/usr/bin/env python

n = input()
print n
