#!/usr/bin/env python

n = input()
print 3.141 * n ** 2
