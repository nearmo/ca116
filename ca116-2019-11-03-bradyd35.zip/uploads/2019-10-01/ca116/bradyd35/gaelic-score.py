#!/usr/bin/env python

g = input()
p = input()
print (3 * g) + (p)
