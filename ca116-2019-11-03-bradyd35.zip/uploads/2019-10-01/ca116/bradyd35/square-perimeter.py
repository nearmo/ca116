#!/usr/bin/env python

n = input()
print 4 * n
