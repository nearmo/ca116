#!/usr/bin/env python

n = raw_input()
m = raw_input()
print m
print n
