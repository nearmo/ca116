#!/usr/bin/env python

x = raw_input()
print x
