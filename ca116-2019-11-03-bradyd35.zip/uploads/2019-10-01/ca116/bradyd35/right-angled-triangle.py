#!/usr/bin/env python

a = input()
b = input()
c = input()
print (a ** 2) == (b ** 2) + (c ** 2)
