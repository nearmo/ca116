#!/usr/bin/env python

n = input()
p = input()
divisor = 10 ** p
clippedNum = n / divisor
ans = clippedNum % 10
print ans
