#!/usr/bin/env python

values = 2 ** bits
