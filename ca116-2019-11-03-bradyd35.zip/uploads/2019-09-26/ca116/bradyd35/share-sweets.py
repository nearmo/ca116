#!/usr/bin/env python

sweets_per_child = sweets / children

sweets_left_over_child = sweets % children
