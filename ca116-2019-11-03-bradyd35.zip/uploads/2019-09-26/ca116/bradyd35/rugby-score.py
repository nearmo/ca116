#!/usr/bin/env python

score = (5 * tries) + (2 * conversions) + (3 * penalties)
