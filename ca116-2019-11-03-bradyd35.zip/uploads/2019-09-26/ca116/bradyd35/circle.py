#!/usr/bin/env python

circumference = 2 * radius * pi

area = pi * (radius ** 2)
