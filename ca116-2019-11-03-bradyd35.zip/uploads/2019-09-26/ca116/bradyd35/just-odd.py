#!/usr/bin/env python

odd = ((n % 2) * n) + ((m % 2) * m)
