#!/usr/bin/env python

l = n

n = m

m = l
