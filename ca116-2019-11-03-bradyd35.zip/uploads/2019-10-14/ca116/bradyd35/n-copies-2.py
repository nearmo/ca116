#!/usr/bin/env python

str = raw_input()
ext = str
n = input()
i = 0

while i < n:
    str = str + "-" + ext
    i = i + 1
print str
