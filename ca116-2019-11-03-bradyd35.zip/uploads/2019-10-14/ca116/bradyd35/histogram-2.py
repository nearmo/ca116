#!/usr/bin/env python

i = 0
n = input()

while i < n:
    m = input()
    print m * "*"
    i = i + 1
