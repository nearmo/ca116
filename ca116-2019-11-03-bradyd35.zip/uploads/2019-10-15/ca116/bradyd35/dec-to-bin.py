#!/usr/bin/env python

n = input()
i = 0
bin = 0

while 1 <= n:
    bin = bin + ((10 ** i) * (n % 2))
    n = n / 2
    i = i + 1

print bin
