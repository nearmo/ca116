#!/usr/bin/env python

a = input()
b = input()

while 0 < b:
    tmp = b
    b = a % b
    a = tmp

print a
