#!/usr/bin/env python

i = 0
sum = 0

while i < 5:
    n = input()
    if n < 0:
        n = n * -1
    sum = sum + n
    i = i + 1

print sum
