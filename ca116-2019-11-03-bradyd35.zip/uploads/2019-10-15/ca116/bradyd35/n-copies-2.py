#!/usr/bin/env python

str = raw_input()
n = input()

print str + ("-" + str) * (n - 1)
