#!/usr/bin/env python

prev = input()
if prev != 0:
    curr = input()
    while curr != 0:
        if prev < curr:
            print "higher"
        elif curr < prev:
            print "lower"
        elif prev == curr:
            print "equal"
        prev = curr
        curr = input()
