#!/usr/bin/env python

n = input()
sum = 0

while n != 0:
    if n < 0:
        n = n * -1
    sum = sum + n
    n = input()

print sum
