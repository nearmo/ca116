#!/usr/bin/env python

i = 0
sum = 0

while i < 5:
    m = input()
    sum = sum + m
    i = i + 1
print sum
