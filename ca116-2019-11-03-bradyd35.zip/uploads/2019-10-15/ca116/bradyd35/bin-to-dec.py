#!/usr/bin/env python

n = raw_input()
i = 0
dec = 0

while i < len(n):
    if int(n[i]) == 1:
        dec = dec * 2 + 1
    elif int(n[i]) == 0:
        dec = dec * 2
    i = i + 1

print dec
