#!/usr/bin/env python

sum = 0
n = input()

while n != 0:
    sum = sum + n
    n = input()

print sum
