#!/usr/bin/env python

n = input()
dig = input()

num = (n / (10 ** dig)) % 10

print num
