#!/usr/bin/env python

sumneg = 0
sumpos = 0

n = input()
while n != 0:
    if n < 0:
        sumneg = sumneg + n
    elif 0 < n:
        sumpos = sumpos + n
    n = input()

print sumneg, sumpos
