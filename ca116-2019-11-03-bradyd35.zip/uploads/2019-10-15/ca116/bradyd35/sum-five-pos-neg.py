#!/usr/bin/env python

i = 0
sumpos = 0
sumneg = 0

while i < 5:
    n = input()
    if 0 < n:
        sumpos = sumpos + n
    elif n < 0:
        sumneg = sumneg + n
    i = i + 1

print sumneg, sumpos
