#!/usr/bin/env python

n = input()
print (n + 1) / 2 == (n) / 2
