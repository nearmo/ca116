#!/usr/bin/env python

n = input()
print (n % 2) * n
