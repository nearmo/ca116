#!/usr/bin/env python

x = input()
y = input()
r = input()
print ((x ** 2) + (y ** 2)) < (r ** 2)
