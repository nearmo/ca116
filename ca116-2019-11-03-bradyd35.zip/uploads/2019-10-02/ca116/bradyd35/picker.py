#!/usr/bin/env python

a = input()
b = input()
c = input()
print (a * ((c + 1) % 2)) + (b * (c % 2))
