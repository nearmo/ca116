#!/usr/bin/env python

a = input()
b = input()
c = input()

if (a ** 2) + (b ** 2) == (c ** 2):
    print "yes"
elif (a ** 2) == (b ** 2) + (c ** 2):
    print "yes"
elif (a ** 2) == (a ** 2) + (c ** 2):
    print "yes"
else:
    print "no"
