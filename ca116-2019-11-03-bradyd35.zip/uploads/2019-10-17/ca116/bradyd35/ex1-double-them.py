#!/usr/bin/env python

i = 0
n = 10

while i < n:
    m = input()
    print m * 2
    i = i + 1
