#!/usr/bin/env python

n = input()
i = 0
while i < n:
   print i
   i = i + 1
