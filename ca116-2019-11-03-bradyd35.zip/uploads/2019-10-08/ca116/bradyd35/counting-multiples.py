#!/usr/bin/env python

n = input()
m = input()
i = 0
while i < n:
   print (i + 1) * m
   i = i + 1
