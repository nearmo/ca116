#!/usr/bin/env python

n = input()
i = 0
while i < n:
   print (i + 1) * 2
   i = i + 1
