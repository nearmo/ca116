#!/usr/bin/env python

n = input()
x = 0
print x
y = 1
print y
while y < n:
    m = x + y
    x = y
    y = m
    if y < n:
        print y
