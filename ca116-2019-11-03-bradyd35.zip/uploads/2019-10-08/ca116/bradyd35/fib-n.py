#!/usr/bin/env python

n = input()
x = 0
y = 1
print x
print y
i = 0
while i < n - 2:
   m = x + y
   x = y
   y = m
   print y
   i = i + 1
