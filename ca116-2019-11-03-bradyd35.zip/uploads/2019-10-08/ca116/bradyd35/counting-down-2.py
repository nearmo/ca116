#!/usr/bin/env python

n = input()
i = 0
while i < n:
   print n - i - 1
   i = i + 1
