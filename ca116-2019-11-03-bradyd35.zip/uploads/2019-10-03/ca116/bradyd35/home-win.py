#!/usr/bin/env python

h = input()
a = input()
if a < h:
    print "Home win."
elif h < a:
    print "Away win."
else:
    print "Draw."
