#!/usr/bin/env python

d = input()
if d <= 6 and 5 <= d:
   print "weekend"
else:
   print "weekday"
