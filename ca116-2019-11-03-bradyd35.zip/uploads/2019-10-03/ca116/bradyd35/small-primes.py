#!/usr/bin/env python

n = input()
if n == 2 or n == 3 or n == 5:
    print "prime"
elif n % 2 == 0 or n == 1 or n % 3 == 0:
    print "not prime"
else:
    print "prime"
