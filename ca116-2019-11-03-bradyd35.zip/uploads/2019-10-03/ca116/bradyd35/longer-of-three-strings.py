#!/usr/bin/env python

a = raw_input()
b = raw_input()
c = raw_input()
if len(a) < len(c) and len(b) < len(c):
    print c
elif len(c) < len(b) and len(a) < len(b):
    print b
elif len(b) < len(a) and len(c) < len(a):
    print a
