#!/usr/bin/env python

n = input()
if n % 2 == 0:
    print n / 2
else:
    print n * 3 + 1
