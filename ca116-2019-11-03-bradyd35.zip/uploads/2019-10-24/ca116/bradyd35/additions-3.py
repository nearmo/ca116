#!/usr/bin/env python

sum = 0
while sum != 1000:
    i = 0
    s = raw_input()
    while i < len(s) and s[i] != "+":
        i = i + 1
    sum = int(s[:i]) + int(s[i + 1:])
    print sum
