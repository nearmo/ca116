#!/usr/bin/env python

s = raw_input()

i = 0
j = 0
sum = 0
while i < len(s):
    while i < len(s) and s[i] != "+":
        i = i + 1
    sum = sum + int(s[j:i])
    j = i + 1
    i = i + 1
print sum
