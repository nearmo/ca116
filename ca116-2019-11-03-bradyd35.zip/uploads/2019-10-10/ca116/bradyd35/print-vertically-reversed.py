#!/usr/bin/env python

s = raw_input()
i = 0

while i < len(s):
    print s[len(s) - 1 - i]
    i = i + 1
