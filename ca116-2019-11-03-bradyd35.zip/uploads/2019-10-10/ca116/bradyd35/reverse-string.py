#!/usr/bin/env python

s = raw_input()
i = 0
reverse = ""

while i < len(s):
    reverse = reverse + s[len(s) - 1 - i]
    i = i + 1
print reverse
