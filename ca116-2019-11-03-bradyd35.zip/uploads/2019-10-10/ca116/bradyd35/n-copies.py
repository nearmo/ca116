#!/usr/bin/env python

s = raw_input()
n = input()
print s * n
