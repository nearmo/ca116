#!/usr/bin/env python

s = raw_input()
i = 0

while i < len(s):
    print s[0 + i:len(s)]
    i = i + 1
