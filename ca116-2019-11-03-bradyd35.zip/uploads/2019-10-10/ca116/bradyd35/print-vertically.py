#!/usr/bin/env python

s = raw_input()
i = 0

while i < len(s):
    print s[i]
    i = i + 1
