#!/usr/bin/env python

i = 0
n = 0

while i < 10:
    n = input()
    print n * "*"
    i = i + 1
