#!/usr/bin/env python

s = raw_input()
i = 0
before = 0
after = 0
while i < len(s):
    while i < len(s) and s[before] != ".":
        before = before + 1
    after = before + 1
    i = i + 1
print s[:before]
print s[after:]
