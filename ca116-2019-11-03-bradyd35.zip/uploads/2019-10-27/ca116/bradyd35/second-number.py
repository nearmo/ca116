#!/usr/bin/env python

s = raw_input()
start = 0
finish = 0
i = 0

while i < 2:
    start = finish
    while start < len(s) and (s[start] < "0" or "9" < s[start]):
        start = start + 1
    finish = start
    while finish < len(s) and ("0" <= s[finish] and s[finish] <= "9"):
        finish = finish + 1
    i = i + 1
if start < len(s):
    print s[start:finish], start
