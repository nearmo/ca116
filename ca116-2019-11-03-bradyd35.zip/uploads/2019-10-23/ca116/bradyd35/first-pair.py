#!/usr/bin/env python

s = raw_input()
i = 0

while i < len(s) and s[i - 1] != s[i]:
    i = i + 1

if i < len(s):
    print s[i - 1:i + 1]
