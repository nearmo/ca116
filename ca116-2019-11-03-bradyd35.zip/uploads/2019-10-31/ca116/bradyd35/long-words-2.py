#!/usr/bin/env python

if __name__ == "__main__":
    a = ["cat", "elephant", "mouse", "lizard", "horse", "mongoose"]

i = 0
while i < len(a) and (a[i] == "" or len(a[i]) < 6):
    i = i + 1
if i < len(a):
    print a[i]
