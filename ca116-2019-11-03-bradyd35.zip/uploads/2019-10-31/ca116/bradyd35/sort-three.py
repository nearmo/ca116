#!/usr/bin/env python

a = []
i = 0
while i < 3:
    n = input()
    a.append(n)
    i = i + 1

min = a[0]
j = 0
while j < 3:
    if a[j] < min:
        min = a[j]
    j = j + 1

max = a[0]
q = 0
while q < 3:
    if max < a[q]:
        max = a[q]
    q = q + 1

mid = a[0]
k = 0
while k < 3:
    if k < 3 and a[k] != max and a[k] != min:
        mid = a[k]
    k = k + 1

print min
print mid
print max
