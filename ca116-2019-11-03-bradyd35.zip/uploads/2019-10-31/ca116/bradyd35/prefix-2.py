#!/usr/bin/env python

if __name__ == "__main__":
    a = ["mountain", "montagne", "mont", "mo", "montages", "zebra", "monthly"]
    s = "mont"
t = len(s)
i = 0
while i < len(a) and a[i][:t] != s:
    i = i + 1
if i < len(a):
    print a[i]
